import { motion } from 'motion/react';
import { appConfig } from '../config/appConfig';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '../lib/utils';

export default function Navbar() {
  const location = useLocation();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 flex justify-between items-center px-8 py-3 bg-slate-900/60 backdrop-blur-lg rounded-full mt-4 mx-auto w-[92%] max-w-7xl border border-sky-300/10 shadow-[0_0_30px_rgba(125,211,252,0.05)]">
      <div className="text-xl font-bold text-sky-300 tracking-tighter">
        AuraCore Systems
      </div>
      
      <div className="hidden md:flex gap-8 items-center">
        {appConfig.navigation.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "transition-all duration-300 hover:text-sky-200 text-sm font-medium",
                isActive 
                  ? "text-sky-300 border-b-2 border-sky-300 pb-1" 
                  : "text-slate-400"
              )}
            >
              {item.label}
            </Link>
          );
        })}
      </div>
      
      <motion.button
        whileTap={{ scale: 0.95 }}
        className="bg-primary/10 border border-primary/20 text-sky-300 px-6 py-2 rounded-full font-medium hover:bg-primary/20 transition-all"
      >
        Acceso
      </motion.button>
    </nav>
  );
}
