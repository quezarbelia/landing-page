/**
 * AuraCore Systems - App Configuration
 * This file serves as the "Paperclip" connection point.
 * Agents can modify these values to change the UI without touching logic.
 */

export const appConfig = {
  theme: {
    name: "Glacier",
    colors: {
      primary: "#7dd3fc", // Ice Blue
      secondary: "#88b4cc",
      tertiary: "#c8a0f0", // Soft Lavender
      background: "#0a0e1a",
      surface: "#0f1524",
      error: "#ff6b6b",
    },
    glass: {
      opacity: 0.6,
      blur: "16px",
      borderOpacity: 0.1,
    }
  },
  navigation: [
    { label: "Inicio", path: "/" },
    { label: "Servicios", path: "/servicios" },
    { label: "Panel", path: "/panel" },
    { label: "Contacto", path: "/contacto" }
  ],
  home: {
    hero: {
      badge: "Sistemas V.4.0 Live",
      title: "Ingeniería de Precisión para el Futuro",
      description: "Arquitectamos microservicios de próxima generación con precisión quirúrgica, optimizando la latencia y escalabilidad para ecosistemas globales.",
      primaryBtn: "Empezar",
      secondaryBtn: "Documentación",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuC415dGsDGlYnHIFtz3xd8my0kmcoskbK-EUTRLRYvTzo0kAnEAeddj1TiI8k6DNXByvawDbEJYdG4ZeYZFus1g9EmyxzUhqYTnVQUkMbIZ8YRQxZY12QGE5wEJi6wGsHOtswL5fRQC-XS2MIkkDu9UKdzcDkmAjm7spY_2TrcSpb6hbSsArJHRI7_Dzp_QaRC_MT0MJoiQq7yePlmhk11HP1I2Ogu7xGb-kxirYDRn5j0V_2AcaTm6P5-IaNJ942YUTTQbiw1bI19M"
    },
    services: {
      title: "Servicios de Élite",
      subtitle: "Sistemas modulares diseñados para resistir las demandas de la computación distribuida moderna.",
      cards: [
        {
          id: "arch",
          icon: "architecture",
          title: "Arquitectura",
          description: "Diseño de sistemas hexagonales con desacoplamiento total de servicios para una mantenibilidad extrema.",
          image: "https://lh3.googleusercontent.com/aida-public/AB6AXuASosVB3nsQ6nuT7rCsA3ORB0Tp_D-7RWcT2qSvi-7vDsdJTDdpvPzNxF3kEkhevM5mD-mk1n76qfzh2OqfSfLlFsVDX7j3JVuQz4betpLMTfp1Ja4wZgBQTYNph719wAdkVrGP9fU1JNObxvN47IgBKy07P4kB3UZd-TbmI2R3m5QibQOjMuSreR1g--5MMqKiDVi5piP_oWiOYh3n9FGiotiEcyoVmPROviN31PGXb8rUrfv6cNPupHji4U3NZWU1MWqULiet4n5L"
        },
        {
          id: "proto",
          icon: "sync_alt",
          title: "Protocolo",
          description: "Comunicación asíncrona de alta fidelidad basada en eventos."
        },
        {
          id: "term",
          icon: "terminal",
          title: "Terminal",
          description: "Interfaces CLI potentes para orquestación en tiempo real."
        }
      ]
    },
    security: {
      title: "Seguridad Cuántica",
      description: "Encriptación de extremo a extremo con protocolos post-cuánticos integrados nativamente en cada microservicio.",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuC45RI7Qo4xfRoBPBR6qdqjXJepLH5-FRxs64TQeVRndvee0yIGuD3NtHaC4rY0k3BeY9wOUQO0gsYKAbQ7djDoK0EwVGoxIlhzSk-cJTY3cjsPxozZdmnmrn8m8MjHEsH6YIs6N1YWGWOGzLXRw8c66d2SsnGmdIkHhReUqFHudAEsQOSk4AkA2RPhLXLch1t1yK8QFzQgfF2jAz80CgEI3E2SydsxGMuo2Gn56xrsYb-wjUud2GuRPMvdSATgpae-LHDqnx4d8E3B"
    }
  },
  dashboard: {
    title: "Panel Operativo Neural",
    description: "Visualización en tiempo real de la arquitectura de microservicios distribuida y estados de núcleo.",
    metrics: [
      { label: "Uptime Global", value: "99.998%", icon: "bolt", color: "primary" },
      { label: "Carga del Sistema", value: "24.2%", icon: "speed", color: "tertiary" },
      { label: "Nodos Activos", value: "1,024", icon: "hub", color: "secondary" }
    ],
    services: [
      { name: "Compute", status: "ESTABLE", progress: 65, description: "Orquestación de clusters efímeros y ejecución serverless." },
      { name: "Storage", status: "ACTIVO", progress: 42, description: "Persistencia distribuida con redundancia geográfica de capa 3." },
      { name: "Vault", status: "BLOQUEADO", progress: 88, description: "Gestión de secretos y rotación de claves HSM de alta seguridad.", isError: true },
      { name: "Analytics", status: "PROCESANDO", progress: 15, description: "Motor de inferencia para telemetría predictiva de red." }
    ]
  },
  footer: {
    copyright: "© 2024 AuraCore Systems. Excelencia en Microservicios.",
    links: ["Privacidad", "Términos", "Soporte", "Documentación"]
  }
};
